
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tazkira` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'احمد ولی','',NULL,NULL,'2023-03-20 12:26:16','2023-03-20 12:26:16'),(56,'جاوید پویا',NULL,NULL,NULL,'2023-03-22 12:09:54','2023-03-22 12:09:54'),(57,'محمد کریمی',NULL,NULL,NULL,'2023-03-22 12:10:20','2023-03-22 12:10:20'),(58,'Khan Wali',NULL,NULL,NULL,'2023-03-22 12:12:09','2023-03-22 12:12:09'),(59,'ddddd',NULL,NULL,NULL,'2023-03-22 12:17:02','2023-03-22 12:17:02'),(60,'test',NULL,NULL,NULL,'2023-03-22 14:23:30','2023-03-22 14:23:30'),(61,'dsddd',NULL,NULL,NULL,'2023-03-23 00:43:15','2023-03-23 00:43:15'),(62,'dsdffd',NULL,NULL,NULL,'2023-03-23 00:44:26','2023-03-23 00:44:26'),(63,'ddd',NULL,NULL,NULL,'2023-03-23 00:45:04','2023-03-23 00:45:04'),(64,'dddd',NULL,NULL,NULL,'2023-03-23 00:45:40','2023-03-23 00:45:40'),(65,'dd',NULL,NULL,NULL,'2023-03-23 00:46:25','2023-03-23 00:46:25'),(69,'ddddddd',NULL,NULL,NULL,'2023-03-23 01:05:33','2023-03-23 01:05:33'),(70,'dsfsdfsdsdf',NULL,NULL,NULL,'2023-03-23 01:05:37','2023-03-23 01:05:37'),(71,'dsfsdfdsf',NULL,NULL,NULL,'2023-03-23 01:09:31','2023-03-23 01:09:31'),(72,'23dffds',NULL,NULL,NULL,'2023-03-23 01:16:20','2023-03-23 01:16:20');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'dsdsfsdsdf','2023-03-20 13:05:08','2023-03-20 13:05:08'),(2,'sdfsdfsdfsfd','2023-03-20 13:05:14','2023-03-20 13:05:14'),(3,'ddddd','2023-03-20 13:06:10','2023-03-20 13:06:10');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_03_07_211207_create_stock_table',1),(6,'2023_03_07_212044_create_items_table',1),(7,'2023_03_07_212045_create_stock_item_table',1),(8,'2023_03_07_212046_create_customers_table',1),(9,'2023_03_07_213817_create_stock_operation_table',1),(10,'2023_03_07_215912_create_transfer_table',1),(11,'2023_03_21_183543_add_hijri_date_to_stock_operation_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (1,'ګدام کالا شوی','2023-03-21 13:55:01','2023-03-21 13:55:01'),(2,'ګدام مواد خوراکی','2023-03-21 13:55:14','2023-03-21 13:55:14');
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_item` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stock_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_item_stock_id_foreign` (`stock_id`),
  KEY `stock_item_item_id_foreign` (`item_id`),
  CONSTRAINT `stock_item_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `stock_item_stock_id_foreign` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_item` WRITE;
/*!40000 ALTER TABLE `stock_item` DISABLE KEYS */;
INSERT INTO `stock_item` VALUES (37,1,1,2,'2023-03-21 23:31:30','2023-03-22 14:23:45'),(38,2,2,11,'2023-03-22 06:26:04','2023-03-22 12:49:44'),(43,1,2,-25,'2023-03-22 12:19:45','2023-03-22 12:49:44'),(46,2,1,23,'2023-03-22 12:53:44','2023-03-22 14:20:27');
/*!40000 ALTER TABLE `stock_item` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_operation` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stock_operation_type` enum('PURCHASE','SELL','RETURN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_number` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `stock_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `customer` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hijri_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_operation_stock_id_foreign` (`stock_id`),
  KEY `stock_operation_item_id_foreign` (`item_id`),
  KEY `stock_operation_customer_foreign` (`customer`),
  CONSTRAINT `stock_operation_customer_foreign` FOREIGN KEY (`customer`) REFERENCES `customers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `stock_operation_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `stock_operation_stock_id_foreign` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_operation` WRITE;
/*!40000 ALTER TABLE `stock_operation` DISABLE KEYS */;
INSERT INTO `stock_operation` VALUES (35,'PURCHASE','23',2,1,1,NULL,'2023-03-21 23:31:30','2023-03-21 23:31:30','1402-01-02'),(38,'PURCHASE','123',5,1,1,NULL,'2023-03-21 23:34:15','2023-03-21 23:34:15','1402-01-02'),(39,'PURCHASE','12',7,1,1,NULL,'2023-03-22 06:26:04','2023-03-22 06:26:04','1402-01-02'),(40,'PURCHASE','12',39,2,2,NULL,'2023-03-22 06:26:04','2023-03-22 06:26:04','1402-01-03'),(45,'SELL','2',21,2,2,1,'2023-03-22 08:24:32','2023-03-22 12:08:14','1402-01-01'),(48,'SELL','23',2,1,1,1,'2023-03-22 10:00:18','2023-03-22 10:00:18','1402-01-02'),(49,'SELL','23',2,1,1,1,'2023-03-22 11:06:08','2023-03-22 14:27:07','1402-01-02'),(50,'SELL','23',2,1,1,1,'2023-03-22 11:08:04','2023-03-22 14:26:58','1402-01-02'),(51,'SELL','50',2,1,1,56,'2023-03-22 12:17:23','2023-03-22 14:27:18','1402-01-02'),(53,'RETURN','23',23,2,1,NULL,'2023-03-22 14:20:27','2023-03-22 14:20:27','1402-01-02'),(54,'SELL','23',2,1,1,1,'2023-03-22 14:23:45','2023-03-22 14:26:49','1402-01-02');
/*!40000 ALTER TABLE `stock_operation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfer` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `bill_number` bigint NOT NULL,
  `from_stock` bigint unsigned NOT NULL,
  `to_stock` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_from_stock_foreign` (`from_stock`),
  KEY `transfer_to_stock_foreign` (`to_stock`),
  KEY `transfer_item_id_foreign` (`item_id`),
  CONSTRAINT `transfer_from_stock_foreign` FOREIGN KEY (`from_stock`) REFERENCES `stock` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transfer_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transfer_to_stock_foreign` FOREIGN KEY (`to_stock`) REFERENCES `stock` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transfer` WRITE;
/*!40000 ALTER TABLE `transfer` DISABLE KEYS */;
INSERT INTO `transfer` VALUES (1,12,1,2,1,2,'2023-03-22 12:39:07','2023-03-22 12:39:07'),(2,23,2,1,1,2,'2023-03-22 12:47:13','2023-03-22 12:47:13'),(3,23,2,1,2,1,'2023-03-22 12:48:23','2023-03-22 12:48:23'),(4,23,2,1,2,1,'2023-03-22 12:49:44','2023-03-22 12:49:44'),(5,23,2,1,2,5,'2023-03-22 12:49:44','2023-03-22 12:49:44');
/*!40000 ALTER TABLE `transfer` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'test','$2y$10$pfht9KIohOPVNAt81sgUyeOjLDpchMMXyHy0vQkS9S2sHOapR7uNe','2023-03-20 12:25:52','2023-03-20 12:25:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

